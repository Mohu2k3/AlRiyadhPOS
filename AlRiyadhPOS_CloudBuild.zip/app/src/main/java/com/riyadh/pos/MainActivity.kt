package com.riyadh.pos

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

private const val GREEN = 0xFF16834A.toInt()
private const val DARK = 0xFF155D38.toInt()

class DB(ctx: Context) : SQLiteOpenHelper(ctx, "riyadh_pos.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,barcode TEXT,qty REAL DEFAULT 0,cost REAL DEFAULT 0,price REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created TEXT,total REAL,paid REAL,customer TEXT,kind TEXT)")
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,name TEXT,qty REAL,price REAL,cost REAL)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,created TEXT,title TEXT,amount REAL)")
        db.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,amount REAL,created TEXT,invoice_id INTEGER)")
        db.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,created TEXT,supplier TEXT,total REAL,paid REAL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun scalar(sql:String): Double = readableDatabase.rawQuery(sql,null).use { if(it.moveToFirst()) it.getDouble(0) else 0.0 }
}

data class CartLine(val name:String,val qty:Double,val price:Double,val cost:Double)

class MainActivity : Activity() {
    private lateinit var db: DB
    private lateinit var root: LinearLayout
    private val cart = mutableListOf<CartLine>()
    private var printer: BluetoothDevice? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=DB(this)
        showHome()
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun txt(s:String,size:Float=16f,bold:Boolean=false): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(0xFF202124.toInt()); if(bold)setTypeface(null,1)
        gravity=Gravity.RIGHT; setPadding(dp(8),dp(8),dp(8),dp(8))
    }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(GREEN)
        setOnClickListener{action()}
    }
    private fun edit(hint:String, number:Boolean=false): EditText = EditText(this).apply {
        this.hint=hint; textSize=16f; gravity=Gravity.RIGHT
        if(number) inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(12),dp(8),dp(12),dp(8))
    }
    private fun page(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(0xFFF4F6F5.toInt()) }
        val head=TextView(this).apply {
            text="الرياض للتجارة والتوزيع\n$title"; textSize=19f; setTextColor(-1); gravity=Gravity.CENTER
            setPadding(dp(10),dp(14),dp(10),dp(14)); setBackgroundColor(DARK); setTypeface(null,1)
        }
        root.addView(head,LinearLayout.LayoutParams(-1,-2))
        val scroll=ScrollView(this)
        val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(20)) }
        scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(0xFFE5ECE8.toInt()) }
        listOf("الرئيسية","بيع","الأصناف","المزيد").forEachIndexed { i,label ->
            val b=TextView(this).apply { text=label; gravity=Gravity.CENTER; textSize=14f; setPadding(2,dp(14),2,dp(14)); setTextColor(DARK); setOnClickListener { when(i){0->showHome();1->showSale();2->showProducts();else->showMore()} } }
            nav.addView(b,LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav); setContentView(root)
        currentBody=body
    }
    private lateinit var currentBody: LinearLayout
    private fun add(view:View) { currentBody.addView(view,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)}) }
    private fun line(s:String) { add(txt(s)) }
    private fun action(s:String, f:()->Unit) { add(button(s,f)) }
    private fun money(v:Double)="%.2f ج.م".format(Locale.US,v)
    private fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale("ar")).format(Date())

    private fun showHome() {
        page("لوحة التحكم")
        val sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM invoices WHERE date(created)=date('now','localtime')")
        val expenses=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date(created)=date('now','localtime')")
        line("مبيعات اليوم: ${money(sales)}")
        line("مصروفات اليوم: ${money(expenses)}")
        line("عدد الأصناف: ${db.scalar("SELECT COUNT(*) FROM products").toInt()}")
        line("قيمة الديون المسجلة: ${money(db.scalar("SELECT COALESCE(SUM(amount),0) FROM debts"))}")
        action("فاتورة بيع جديدة") { showSale() }
        action("إضافة صنف للمخزون") { addProductDialog() }
        action("توصيل طابعة Deli DL-ES421") { choosePrinter() }
        action("المشتريات") { showPurchases() }
        action("المصروفات") { showExpenses() }
        action("التقارير") { showReports() }
        line("ملاحظة: الربح الدقيق يحتاج جرد أول وآخر المدة وتسجيل كل المشتريات والمصروفات.")
    }

    private fun showProducts() {
        page("الأصناف والمخزون")
        action("إضافة صنف جديد") { addProductDialog() }
        val c=db.readableDatabase.rawQuery("SELECT name,qty,cost,price FROM products ORDER BY name",null)
        if(!c.moveToFirst()) line("لا توجد أصناف. أضف أول صنف.")
        else do { line("${c.getString(0)}  | الكمية: ${c.getDouble(1)} | شراء: ${money(c.getDouble(2))} | بيع: ${money(c.getDouble(3))}") } while(c.moveToNext())
        c.close()
    }
    private fun addProductDialog() {
        val box=LinearLayout(this).apply{orientation=1;setPadding(dp(18),0,dp(18),0)}
        val n=edit("اسم الصنف"); val q=edit("الكمية الحالية",true); val cost=edit("سعر الشراء",true); val price=edit("سعر البيع",true); val barcode=edit("الباركود (اختياري)")
        listOf(n,q,cost,price,barcode).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("إضافة صنف").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            if(n.text.isNotBlank()) db.writableDatabase.execSQL("INSERT OR REPLACE INTO products(name,barcode,qty,cost,price) VALUES(?,?,?,?,?)", arrayOf(n.text.toString(),barcode.text.toString(),q.num(),cost.num(),price.num()))
            showProducts()
        }.show()
    }

    private fun showSale() {
        page("فاتورة بيع")
        val name=edit("اسم الصنف"); val qty=edit("الكمية",true); val price=edit("سعر البيع للوحدة",true)
        add(name); add(qty); add(price)
        action("إضافة للسلة") {
            val nm=name.text.toString().trim()
            if(nm.isEmpty() || qty.num()<=0 || price.num()<0){toast("أدخل الصنف والكمية والسعر");return@action}
            val c=db.readableDatabase.rawQuery("SELECT cost FROM products WHERE name=?",arrayOf(nm))
            val cost=if(c.moveToFirst())c.getDouble(0) else 0.0;c.close()
            cart.add(CartLine(nm,qty.num(),price.num(),cost))
            name.text.clear();qty.text.clear();price.text.clear(); renderCart()
        }
        action("مسح السلة") { cart.clear(); showSale() }
        renderCart()
    }
    private fun renderCart() {
        line("محتويات الفاتورة")
        cart.forEachIndexed { i,x -> line("${i+1}. ${x.name} — ${x.qty} × ${money(x.price)} = ${money(x.qty*x.price)}") }
        val total=cart.sumOf{it.qty*it.price}
        line("الإجمالي: ${money(total)}")
        val customer=edit("اسم العميل (اختياري)")
        val paid=edit("المبلغ المدفوع",true); paid.setText(total.toString())
        add(customer);add(paid)
        action("حفظ الفاتورة وطباعة") {
            if(cart.isEmpty()){toast("السلة فارغة");return@action}
            val paidValue=paid.num().coerceAtLeast(0.0)
            val dbw=db.writableDatabase
            dbw.beginTransaction()
            var invoiceId=0L
            try {
                val cv=android.content.ContentValues().apply{put("created",now());put("total",total);put("paid",paidValue);put("customer",customer.text.toString());put("kind","بيع")}
                invoiceId=dbw.insert("invoices",null,cv)
                cart.forEach { x ->
                    dbw.execSQL("INSERT INTO invoice_items(invoice_id,name,qty,price,cost) VALUES(?,?,?,?,?)",arrayOf(invoiceId,x.name,x.qty,x.price,x.cost))
                    dbw.execSQL("UPDATE products SET qty=qty-? WHERE name=?",arrayOf(x.qty,x.name))
                }
                if(paidValue<total) dbw.execSQL("INSERT INTO debts(customer,amount,created,invoice_id) VALUES(?,?,?,?)",arrayOf(customer.text.toString().ifBlank{"عميل نقدي/آجل"},total-paidValue,now(),invoiceId))
                dbw.setTransactionSuccessful()
            } finally {dbw.endTransaction()}
            val receipt=buildReceipt(invoiceId.toInt(),cart.toList(),total,paidValue,customer.text.toString())
            cart.clear(); printReceipt(receipt); toast("تم حفظ الفاتورة رقم $invoiceId"); showHome()
        }
    }

    private fun showPurchases() {
        page("المشتريات")
        val supplier=edit("اسم المورد"); val name=edit("اسم الصنف"); val qty=edit("الكمية",true); val cost=edit("تكلفة الوحدة",true); val paid=edit("المدفوع للمورد",true)
        listOf(supplier,name,qty,cost,paid).forEach{add(it)}
        action("حفظ المشتريات") {
            if(name.text.isBlank()||qty.num()<=0){toast("أدخل بيانات الصنف والكمية");return@action}
            val total=qty.num()*cost.num()
            val w=db.writableDatabase
            w.execSQL("INSERT OR REPLACE INTO products(name,qty,cost,price) VALUES(?,COALESCE((SELECT qty FROM products WHERE name=?),0)+?,?,COALESCE((SELECT price FROM products WHERE name=?),0))",arrayOf(name.text.toString(),name.text.toString(),qty.num(),cost.num(),name.text.toString()))
            w.execSQL("INSERT INTO purchases(created,supplier,total,paid) VALUES(?,?,?,?)",arrayOf(now(),supplier.text.toString(),total,paid.num()))
            toast("تم تسجيل المشتريات");showHome()
        }
    }
    private fun showExpenses() {
        page("المصروفات")
        val title=edit("بيان المصروف"); val amount=edit("المبلغ",true)
        add(title);add(amount)
        action("حفظ المصروف") {
            if(title.text.isBlank()||amount.num()<=0){toast("أدخل البيان والمبلغ");return@action}
            db.writableDatabase.execSQL("INSERT INTO expenses(created,title,amount) VALUES(?,?,?)",arrayOf(now(),title.text.toString(),amount.num()))
            toast("تم حفظ المصروف");showHome()
        }
    }
    private fun showInvoices() {
        page("الفواتير")
        val c=db.readableDatabase.rawQuery("SELECT id,created,total,paid,customer FROM invoices ORDER BY id DESC LIMIT 100",null)
        if(!c.moveToFirst())line("لا توجد فواتير")
        else do{line("فاتورة #${c.getInt(0)} | ${c.getString(1)} | ${money(c.getDouble(2))} | مدفوع ${money(c.getDouble(3))} | ${c.getString(4)}")}while(c.moveToNext())
        c.close()
    }
    private fun showDebts() {
        page("الديون")
        val c=db.readableDatabase.rawQuery("SELECT customer,SUM(amount) FROM debts GROUP BY customer",null)
        if(!c.moveToFirst())line("لا توجد ديون مسجلة")
        else do{line("${c.getString(0)}: ${money(c.getDouble(1))}")}while(c.moveToNext())
        c.close()
        val n=edit("اسم العميل للسداد");val a=edit("مبلغ السداد",true);add(n);add(a)
        action("تسجيل سداد") {
            if(n.text.isBlank()||a.num()<=0)return@action
            val remaining=a.num()
            val cur=db.readableDatabase.rawQuery("SELECT id,amount FROM debts WHERE customer=? ORDER BY id",arrayOf(n.text.toString()))
            var left=remaining
            val updates=mutableListOf<Pair<Int,Double>>()
            while(cur.moveToNext()&&left>0){val old=cur.getDouble(1);val used=minOf(old,left);updates.add(cur.getInt(0) to (old-used));left-=used}
            cur.close()
            updates.forEach{(id,v)->if(v<=0)db.writableDatabase.delete("debts","id=?",arrayOf(id.toString())) else db.writableDatabase.execSQL("UPDATE debts SET amount=? WHERE id=?",arrayOf(v,id))}
            toast("تم تسجيل السداد");showDebts()
        }
    }
    private fun showMore() {
        page("المزيد")
        action("الفواتير السابقة") { showInvoices() }
        action("الديون والعملاء") { showDebts() }
        action("المشتريات والموردون") { showPurchases() }
        action("المصروفات") { showExpenses() }
        action("التقارير") { showReports() }
        action("إعداد الطابعة") { choosePrinter() }
    }
    private fun showReports() {
        page("التقارير")
        val sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM invoices")
        val cost=db.scalar("SELECT COALESCE(SUM(qty*cost),0) FROM invoice_items")
        val exp=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses")
        line("إجمالي المبيعات: ${money(sales)}")
        line("تكلفة البضاعة المباعة المسجلة: ${money(cost)}")
        line("مجمل الربح التقديري: ${money(sales-cost)}")
        line("إجمالي المصروفات المسجلة: ${money(exp)}")
        line("صافي الربح التقديري: ${money(sales-cost-exp)}")
        line("تنبيه: الأرقام تعتمد على تسجيل كل حركة ومراجعة الجرد والمرتجعات.")
    }

    private fun choosePrinter() {
        val adapter=BluetoothAdapter.getDefaultAdapter()
        if(adapter==null){toast("الموبايل لا يدعم Bluetooth");return}
        if(!adapter.isEnabled){startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),10);return}
        val devices=adapter.bondedDevices?.toList() ?: emptyList()
        if(devices.isEmpty()){toast("اربط الطابعة أولاً من إعدادات البلوتوث. اسمها DL-ES421 والرقم 0000");return}
        val names=devices.map{"${it.name} (${it.address})"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("اختر الطابعة").setItems(names){_,which->
            printer=devices[which]; getSharedPreferences("p",0).edit().putString("mac",printer!!.address).apply()
            toast("تم اختيار ${printer!!.name}")
        }.show()
    }
    private fun printReceipt(text:String) {
        val mac=printer?.address ?: getSharedPreferences("p",0).getString("mac",null)
        if(mac==null){toast("اختر الطابعة أولاً من زر توصيل الطابعة");return}
        val device=BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(mac) ?: return
        thread {
            try {
                val socket=device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                socket.connect()
                val out=socket.outputStream
                out.write(byteArrayOf(0x1B,0x40))
                val bmp=renderReceipt(text)
                out.write(bitmapToEscPos(bmp))
                out.write(byteArrayOf(0x0A,0x0A,0x0A,0x1D,0x56,0x00))
                out.flush();socket.close()
                runOnUiThread{toast("تم إرسال الفاتورة للطابعة")}
            } catch(e:Exception){runOnUiThread{toast("تعذر الطباعة: ${e.message}. تأكد من اقتران الطابعة.")}}
        }
    }
    private fun buildReceipt(id:Int,items:List<CartLine>,total:Double,paid:Double,customer:String):String {
        return buildString {
            append("الرياض للتجارة والتوزيع\n")
            append("فاتورة بيع رقم: $id\n")
            append("${now()}\n")
            if(customer.isNotBlank())append("العميل: $customer\n")
            append("--------------------------------\n")
            items.forEach{append("${it.name}\n${it.qty} × ${money(it.price)} = ${money(it.qty*it.price)}\n")}
            append("--------------------------------\n")
            append("الإجمالي: ${money(total)}\n")
            append("المدفوع: ${money(paid)}\n")
            append("الباقي: ${money((total-paid).coerceAtLeast(0.0))}\n")
            append("\nشكراً لتعاملكم معنا\n")
        }
    }
    private fun renderReceipt(text:String):Bitmap {
        val width=384
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=25f;typeface=Typeface.create("sans-serif",Typeface.NORMAL);textAlign=Paint.Align.RIGHT}
        val lines=text.split("\n")
        val lineH=34
        val bmp=Bitmap.createBitmap(width,maxOf(160,lines.size*lineH+30),Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bmp);canvas.drawColor(Color.WHITE)
        var y=34f
        lines.forEachIndexed{index,line->
            val p=if(index==0)Paint(paint).apply{textSize=29f;typeface=Typeface.DEFAULT_BOLD}else paint
            canvas.drawText(line,376f,y,p);y+=lineH
        }
        return bmp
    }
    private fun bitmapToEscPos(bmp:Bitmap):ByteArray {
        val w=((bmp.width+7)/8)*8;val h=bmp.height
        val bytes=java.io.ByteArrayOutputStream()
        val widthBytes=w/8
        bytes.write(byteArrayOf(0x1D,0x76,0x30,0x00,(widthBytes and 0xFF).toByte(),(widthBytes shr 8).toByte(),(h and 0xFF).toByte(),(h shr 8).toByte()))
        for(y in 0 until h) for(bx in 0 until widthBytes){
            var value=0
            for(bit in 0..7){
                val x=bx*8+bit
                if(x<bmp.width){
                    val pixel=bmp.getPixel(x,y)
                    val gray=(Color.red(pixel)*299+Color.green(pixel)*587+Color.blue(pixel)*114)/1000
                    if(gray<160)value=value or (1 shl (7-bit))
                }
            }
            bytes.write(value)
        }
        return bytes.toByteArray()
    }
    private fun EditText.num():Double= text.toString().replace(',','.').toDoubleOrNull()?:0.0
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
